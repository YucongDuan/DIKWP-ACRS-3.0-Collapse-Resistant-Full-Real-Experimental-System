# Evidence Ledger Template

| ID | Source | Type | Claim | Support Scope | Not Supported | Reliability | Borrowed | Kill Condition |
|---|---|---|---|---|---|---|---|---|
| E1 | GitHub public repository page | Web | Repository exists and lists delivery assets | Repo-level description only | Does not verify internal zip content | Supported | Yes | Repo page changes or artifact cannot be opened |
| E2 | ResearchGate publication page | Web | Collapse theory text available | Visible page text only | Does not prove theory correctness | Supported/Theoretical Borrowed | Yes | Peer critique or incompatible evidence |
| E3 | Local experiments | RunProof | Code executes and metrics generated | Local closed-lab run | Does not prove phenomenal consciousness | Supported/RunProof | No | Reproduction failure |
