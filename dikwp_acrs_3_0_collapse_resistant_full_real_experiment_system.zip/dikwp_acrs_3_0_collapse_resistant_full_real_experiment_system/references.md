# References and Source Notes

This package uses public source descriptions and visible ResearchGate/GitHub text as Borrowed sources. It does not copy closed payloads from GitHub zip files.

Key source families:

- YucongDuan GitHub repositories page and visible repository descriptions.
- ResearchGate: Introduction to the DIKWP Artificial Consciousness System.
- ResearchGate: STRATEGIC REPORT DIKWP Collapse Background Mechanism Report.
- User-provided DIKWP-Mesh 3.0 Master Invocation Prompt.
- User-provided life-centered consciousness material.
