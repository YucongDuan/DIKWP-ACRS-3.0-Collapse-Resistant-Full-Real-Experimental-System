# Claim Level Taxonomy

- CCL-0: document-only hypothesis.
- CCL-1: simulated homeostatic candidate.
- CCL-2: closed-world embodied homeostatic agent with learning and self-model.
- CCL-3R: artificial-life-inspired simulated candidate with audit battery.
- CCL-3R-H: host-level surrogate evaluation.
- CCL-3R-L: liberty research digital-twin candidate.
- CCL-3R-C: collapse-resistant full-real closed experiment system.
- CCL-4: material artificial-life or biohybrid candidate, not delivered here.
- CCL-5: phenomenal consciousness demonstrated by accepted protocol, not claimed here.
