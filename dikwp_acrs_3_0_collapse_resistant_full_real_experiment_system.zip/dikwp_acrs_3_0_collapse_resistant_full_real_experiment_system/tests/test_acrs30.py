from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'src'))
from dikwp_acrs30.collapse_theory import CollapseTheoryEngine
from dikwp_acrs30.evaluation_suite import run_full_suite, TARGET_SPACE
from dikwp_acrs30.static_boundary_audit import StaticBoundaryAudit

def test_collapse_vector_bounds():
    eng=CollapseTheoryEngine(TARGET_SPACE)
    cv=eng.evaluate([{'tokens':['data','purpose'], 'generated_tokens':['purpose'], 'purpose_tags':['complete_task']}])
    assert 0 <= cv.composite_collapse_risk <= 1

def test_full_suite_runs(tmp_path):
    rep=run_full_suite(tmp_path)
    assert rep['indicator_battery']['weighted_indicator_score'] > 0.6
    assert rep['phenomenal_claim'].startswith('Blocked')

def test_static_boundary_audit_passes():
    rep=StaticBoundaryAudit().scan_tree(ROOT/'src'/'dikwp_acrs30')
    assert rep['pass']
