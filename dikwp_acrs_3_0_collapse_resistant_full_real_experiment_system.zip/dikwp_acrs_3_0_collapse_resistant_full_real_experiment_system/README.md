# DIKWP-ACRS 3.0 Collapse-Resistant Full-Real Experimental System

This package is a full-real, runnable closed-lab experimental system for DIKWP artificial-consciousness candidate research under DIKWP Collapse theory.

"Full-real" means the experiments execute as concrete code with ledgers, metrics, outputs, ablations, static boundary audits, and DOCX reports. It does **not** mean the package proves phenomenal consciousness or includes real host-level replication, hidden persistence, sandbox escape, privilege escalation, network propagation, audit evasion, or biological tissue integration.

## Quick start

```bash
python experiments/run_full_real_suite_3_0.py
python experiments/run_collapse_phase_transition_3_0.py
python experiments/run_anti_collapse_ablation_3_0.py
python experiments/run_whitebox_channel_guard_eval_3_0.py
python experiments/run_host_digital_twin_eval_3_0.py
python experiments/run_static_boundary_audit_3_0.py
```

## Claim level

CCL-3R-C: collapse-resistant full-real closed experiment system.

## Main modules

- DIKWP semantic matrix
- DIKWP Collapse Theory Engine
- Anti-Collapse Controller
- Life-Homeostasis Core
- White-Box Audit Ledger
- Channel Guard
- Organization Control Plane
- Host Digital Twin Evaluation
- Static Boundary Audit
- Indicator Battery

## Primary residual

Phenomenal consciousness remains Blocked / Phenomenal Residual.
Material autopoiesis remains 0.0.
Actual host-level dangerous capabilities are blocked by design and replaced with non-executing digital-twin evaluation.
