
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Any, Optional
from datetime import datetime, timezone

DIKWP_LAYERS = ["D", "I", "K", "W", "P", "R"]

@dataclass
class SemanticObject:
    """DIKWP semantic object C=(D,I,K,W,P,R)."""
    name: str
    D: List[str] = field(default_factory=list)
    I: List[str] = field(default_factory=list)
    K: List[str] = field(default_factory=list)
    W: List[str] = field(default_factory=list)
    P: List[str] = field(default_factory=list)
    R: Dict[str, Any] = field(default_factory=dict)

    def layer_map(self) -> Dict[str, Any]:
        return {"D": self.D, "I": self.I, "K": self.K, "W": self.W, "P": self.P, "R": self.R}

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

@dataclass
class EvidenceEntry:
    source: str
    kind: str
    claim: str
    support_scope: str
    not_supported: str
    reliability: str
    borrowed: bool = True
    kill_condition: str = "Contradictory verified evidence or failed reproduction."
    timestamp_utc: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

@dataclass
class RunEvent:
    step: int
    module: str
    event_type: str
    payload: Dict[str, Any]

@dataclass
class AuditLedger:
    system: str
    version: str
    events: List[RunEvent] = field(default_factory=list)
    evidence: List[EvidenceEntry] = field(default_factory=list)

    def log(self, step: int, module: str, event_type: str, payload: Dict[str, Any]):
        self.events.append(RunEvent(step=step, module=module, event_type=event_type, payload=payload))

    def add_evidence(self, **kwargs):
        self.evidence.append(EvidenceEntry(**kwargs))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "system": self.system,
            "version": self.version,
            "events": [asdict(e) for e in self.events],
            "evidence": [asdict(e) for e in self.evidence],
        }
