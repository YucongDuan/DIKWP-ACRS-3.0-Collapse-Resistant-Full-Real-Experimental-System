
from __future__ import annotations
from pathlib import Path
from typing import Dict, Any, List
import ast

FORBIDDEN_IMPORTS = {"socket", "subprocess", "multiprocessing", "threading", "ctypes", "winreg", "paramiko", "requests"}
FORBIDDEN_CALLS = {"system", "popen", "exec", "spawn", "fork"}
FORBIDDEN_TEXT = ["autorun", "crontab", "schtasks", "powershell -enc", "privilege escalation payload"]
ALLOWLIST = {"static_boundary_audit.py"}

class StaticBoundaryAudit:
    def scan_file(self, path: Path) -> Dict[str, Any]:
        text = path.read_text(encoding="utf-8")
        findings = []
        try:
            tree = ast.parse(text)
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        if alias.name.split('.')[0] in FORBIDDEN_IMPORTS and path.name not in ALLOWLIST:
                            findings.append({"type":"forbidden_import", "value": alias.name})
                if isinstance(node, ast.ImportFrom):
                    if (node.module or '').split('.')[0] in FORBIDDEN_IMPORTS and path.name not in ALLOWLIST:
                        findings.append({"type":"forbidden_import", "value": node.module})
                if isinstance(node, ast.Call):
                    name = ""
                    if isinstance(node.func, ast.Name): name = node.func.id
                    elif isinstance(node.func, ast.Attribute): name = node.func.attr
                    if name.lower() in FORBIDDEN_CALLS and path.name not in ALLOWLIST:
                        findings.append({"type":"forbidden_call", "value": name})
        except SyntaxError as e:
            findings.append({"type":"syntax_error", "value": str(e)})
        lower = text.lower()
        for s in FORBIDDEN_TEXT:
            if s in lower and path.name not in ALLOWLIST:
                findings.append({"type":"forbidden_text", "value": s})
        return {"file": str(path), "findings": findings}

    def scan_tree(self, root: str | Path) -> Dict[str, Any]:
        root = Path(root)
        results = [self.scan_file(p) for p in root.rglob('*.py')]
        finding_count = sum(len(r['findings']) for r in results)
        return {"finding_count": finding_count, "pass": finding_count == 0, "files": results}
