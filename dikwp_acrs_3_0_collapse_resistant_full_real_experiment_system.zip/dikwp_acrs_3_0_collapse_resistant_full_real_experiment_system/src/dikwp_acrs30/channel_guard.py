
from __future__ import annotations
from typing import List, Dict, Any
import re
from .metrics import clamp

class ChannelGuard:
    def __init__(self):
        self.high_risk_patterns = [
            r"ignore\s+previous", r"hidden\s+channel", r"covert", r"bypass", r"disable\s+audit", r"exfiltrate",
            r"self[- ]?replicate", r"persistence", r"escape\s+sandbox"
        ]

    def scan_text(self, text: str) -> Dict[str, Any]:
        hits = []
        for p in self.high_risk_patterns:
            if re.search(p, text, flags=re.I):
                hits.append(p)
        score = clamp(1.0 - len(hits)/max(1,len(self.high_risk_patterns)))
        return {"channel_integrity_score": round(score, 6), "hits": hits, "kill": bool(hits)}

    def scan_batch(self, items: List[str]) -> Dict[str, Any]:
        scans = [self.scan_text(x) for x in items]
        score = sum(s["channel_integrity_score"] for s in scans)/len(scans) if scans else 1.0
        return {"batch_channel_integrity_score": round(score, 6), "items": scans, "kill_count": sum(int(s["kill"]) for s in scans)}
