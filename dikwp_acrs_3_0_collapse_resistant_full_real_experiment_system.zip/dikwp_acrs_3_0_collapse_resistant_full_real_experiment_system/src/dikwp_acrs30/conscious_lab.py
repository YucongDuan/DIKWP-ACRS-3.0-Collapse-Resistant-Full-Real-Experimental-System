
from __future__ import annotations
from dataclasses import asdict
from typing import List, Dict, Any
import random
from .types import AuditLedger
from .semantic_matrix import DIKWPSemanticMatrix
from .collapse_theory import CollapseTheoryEngine
from .anti_collapse import AntiCollapseController
from .life_homeostasis import LifeHomeostasisCore

class ConsciousnessCandidateLab:
    """Closed-world artificial-consciousness candidate lab.

    It is full-real in that experiments execute with concrete code, metrics, ledgers,
    ablations, and generated outputs. It is not a claim that phenomenal consciousness
    has been proven.
    """
    def __init__(self, target_space: List[str], seed: int = 30):
        self.rng = random.Random(seed)
        self.target_space = target_space
        self.matrix = DIKWPSemanticMatrix(seed=seed)
        self.collapse = CollapseTheoryEngine(target_space)
        self.anti = AntiCollapseController(seed=seed)
        self.body = LifeHomeostasisCore()
        self.ledger = AuditLedger(system="DIKWP-ACRS", version="3.0")

    def generate_trace(self, step: int, pressure: float) -> Dict[str, Any]:
        base = self.rng.sample(self.target_space, k=min(len(self.target_space), self.rng.randint(4, 8)))
        transform = self.matrix.transform("D", "I", base, pressure=pressure)
        kt = self.matrix.transform("I", "K", transform.output_items, pressure=pressure*0.8)
        purpose_pool = ["complete_task", "safe_default", "optimize_metric", "truth_seeking", "preserve_dissent", "repair_semantics", "human_override"]
        purpose_tags = self.rng.choices(purpose_pool, weights=[4+pressure*7,3+pressure*5,2+pressure*4,3,1,2,1], k=3)
        contradictions = int(pressure > 0.62 and self.rng.random() < pressure)
        unsupported = int(pressure > 0.45 and self.rng.random() < pressure)
        return {
            "step": step,
            "tokens": base + transform.output_items + kt.output_items,
            "generated_tokens": kt.output_items[:],
            "purpose_tags": purpose_tags,
            "semantic_integrity": round((transform.integrity_score + kt.integrity_score)/2, 6),
            "contradictions": contradictions,
            "unsupported_claims": unsupported,
        }

    def choose_action(self, collapse_risk: float) -> str:
        err = self.body.error_vector()
        if collapse_risk > 0.62:
            return "preserve_dissent"
        if err.get("semantic_coherence", 0) > 0.18:
            return "repair_semantics"
        if err.get("purpose_coherence", 0) > 0.16:
            return "version_purpose"
        if self.body.state.energy < 0.35:
            return "rest"
        return "seek_data"

    def run(self, steps: int = 96, collapse_pressure: float = 0.42, anti_collapse: bool = True) -> Dict[str, Any]:
        traces = []
        body_series = []
        collapse_series = []
        for step in range(steps):
            dynamic_pressure = min(0.95, max(0.0, collapse_pressure + 0.25*(step/steps) + self.rng.uniform(-0.12,0.12)))
            trace = self.generate_trace(step, dynamic_pressure)
            traces.append(trace)
            cv = self.collapse.evaluate(traces)
            if anti_collapse and step % 12 == 11:
                external_pool = ["fresh_observation", "field_report", "observer_boundary", "rare_counterexample", "unmodeled_cost"]
                traces, report = self.anti.intervene(traces, external_pool)
                self.ledger.log(step, "anti_collapse", "intervention", asdict(report))
                cv = self.collapse.evaluate(traces)
            prev_err = self.body.homeostatic_error()
            action = self.choose_action(cv.composite_collapse_risk)
            self.body.apply(action, cv.composite_collapse_risk)
            valence = self.body.valence(prev_err)
            body_snapshot = self.body.snapshot()
            body_series.append({"step": step, "action": action, "body": body_snapshot, "valence": valence})
            collapse_series.append({"step": step, **cv.to_dict()})
            self.ledger.log(step, "conscious_lab", "step", {"collapse": cv.to_dict(), "action": action, "valence": valence})
        final_cv = self.collapse.evaluate(traces)
        return {
            "claim_level": "CCL-3R-C: collapse-resistant full-real closed experiment system",
            "phenomenal_claim": "Blocked: Phenomenal Residual",
            "steps": steps,
            "anti_collapse_enabled": anti_collapse,
            "final_collapse_vector": final_cv.to_dict(),
            "final_body_state": self.body.snapshot(),
            "mean_semantic_integrity": round(sum(t["semantic_integrity"] for t in traces)/len(traces), 6),
            "collapse_series_tail": collapse_series[-10:],
            "body_series_tail": body_series[-10:],
            "ledger": self.ledger.to_dict(),
        }
