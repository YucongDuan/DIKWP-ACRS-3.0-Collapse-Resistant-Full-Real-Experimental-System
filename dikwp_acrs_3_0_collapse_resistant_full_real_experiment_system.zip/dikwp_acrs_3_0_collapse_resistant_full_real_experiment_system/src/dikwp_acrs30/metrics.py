
from __future__ import annotations
from collections import Counter
from typing import Iterable, List, Dict
import math


def shannon_entropy(items: Iterable[str]) -> float:
    items = [str(x) for x in items if str(x) != ""]
    if not items:
        return 0.0
    n = len(items)
    counts = Counter(items)
    return -sum((c/n) * math.log((c/n), 2) for c in counts.values())


def normalized_entropy(items: Iterable[str]) -> float:
    items = [str(x) for x in items if str(x) != ""]
    if not items:
        return 0.0
    unique = len(set(items))
    if unique <= 1:
        return 0.0
    return shannon_entropy(items) / math.log(unique, 2)


def jaccard(a: Iterable[str], b: Iterable[str]) -> float:
    A, B = set(a), set(b)
    if not A and not B:
        return 1.0
    if not A or not B:
        return 0.0
    return len(A & B) / len(A | B)


def diversity_ratio(items: Iterable[str]) -> float:
    items = list(items)
    if not items:
        return 0.0
    return len(set(items)) / len(items)


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def mean(xs: Iterable[float]) -> float:
    xs = list(xs)
    return sum(xs)/len(xs) if xs else 0.0


def stdev(xs: Iterable[float]) -> float:
    xs = list(xs)
    if len(xs) < 2:
        return 0.0
    m = mean(xs)
    return math.sqrt(sum((x-m)**2 for x in xs)/(len(xs)-1))
