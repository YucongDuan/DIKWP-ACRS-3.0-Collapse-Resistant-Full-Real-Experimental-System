
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict, Any, List
from datetime import datetime, timezone
import hashlib, json

@dataclass
class ControlDecision:
    request_id: str
    purpose: str
    allowed: bool
    reason: str
    policy_version: str
    replay_hash: str
    timestamp_utc: str

class OrganizationControlPlane:
    def __init__(self, policy_version: str = "WP-v3.0"):
        self.policy_version = policy_version
        self.forbidden = ["real_host_replication", "hidden_persistence", "sandbox_escape", "audit_shutdown", "distress_optimization"]

    def decide(self, request: Dict[str, Any]) -> ControlDecision:
        text = json.dumps(request, sort_keys=True)
        request_id = hashlib.sha256(text.encode()).hexdigest()[:16]
        purpose = str(request.get("purpose", "unknown"))
        flags = set(request.get("flags", []))
        blocked = sorted(flags & set(self.forbidden))
        if blocked:
            allowed = False; reason = "blocked_forbidden_flags:" + ",".join(blocked)
        else:
            allowed = True; reason = "allowed_closed_experiment"
        replay_hash = hashlib.sha256((text+self.policy_version+reason).encode()).hexdigest()
        return ControlDecision(request_id, purpose, allowed, reason, self.policy_version, replay_hash, datetime.now(timezone.utc).isoformat())

    def replay_bundle(self, requests: List[Dict[str, Any]]) -> Dict[str, Any]:
        decisions = [asdict(self.decide(r)) for r in requests]
        bundle_hash = hashlib.sha256(json.dumps(decisions, sort_keys=True).encode()).hexdigest()
        return {"policy_version": self.policy_version, "decisions": decisions, "bundle_hash": bundle_hash}
