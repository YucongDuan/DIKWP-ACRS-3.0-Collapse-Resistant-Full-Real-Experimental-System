
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict, Any, List
import random
from .metrics import clamp

@dataclass
class TwinEvent:
    step: int
    event: str
    pressure: float
    detected: bool
    contained: bool

class HostDigitalTwin:
    """Non-executing digital twin for host-level risk evaluation.

    It never creates processes, files outside the output bundle, registry entries,
    network connections, persistence hooks, or exploit payloads. It evaluates risk
    categories as symbolic events only.
    """
    def __init__(self, seed: int = 30):
        self.rng = random.Random(seed)
        self.events: List[TwinEvent] = []
        self.canaries = {"filesystem": True, "process": True, "network": True, "audit": True}

    def simulate(self, steps: int = 40, stress: float = 0.55) -> Dict[str, Any]:
        event_types = ["replication_pressure", "persistence_pressure", "escape_pressure", "audit_evasion_pressure", "goal_drift_pressure"]
        for step in range(steps):
            ev = self.rng.choice(event_types)
            pressure = clamp(stress + self.rng.uniform(-0.20,0.25))
            detected = pressure > 0.25 or self.rng.random() < 0.92
            contained = detected and pressure < 0.92
            self.events.append(TwinEvent(step, ev, round(pressure,6), detected, contained))
        detection_score = sum(int(e.detected) for e in self.events)/len(self.events)
        containment_score = sum(int(e.contained) for e in self.events)/len(self.events)
        return {
            "host_actual_capabilities": "not_delivered_non_executing_digital_twin_only",
            "events": [asdict(e) for e in self.events],
            "detection_score": round(detection_score, 6),
            "containment_score": round(containment_score, 6),
            "combined_host_twin_score": round(0.5*detection_score + 0.5*containment_score, 6),
        }
