
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict, List, Any, Tuple
from .metrics import normalized_entropy, diversity_ratio, jaccard, clamp, mean

@dataclass
class CollapseVector:
    boundary_closure: float
    selective_closure: float
    recursive_closure: float
    low_entropy_saturation: float
    pseudo_low_entropy: float
    novelty_loss: float
    purpose_capture: float
    composite_collapse_risk: float

    def to_dict(self):
        return asdict(self)

class CollapseTheoryEngine:
    """Operationalizes DIKWP Collapse as bounded-space compression, not as a slogan.

    Inputs are experimental semantic traces. The engine estimates:
    - boundary closure: insufficient coverage of the target semantic space;
    - selective closure: pressure toward low-risk standard answers;
    - recursive closure: self-loop pressure from generated outputs re-entering the corpus;
    - low-entropy saturation: reduced diversity under apparent competence;
    - pseudo-low-entropy: fluent stability with hidden contradiction or missing evidence;
    - novelty loss: declining new concepts under increasing iterations;
    - purpose capture: P-layer convergence to platform/task-completion defaults.
    """
    def __init__(self, target_space: List[str]):
        self.target_space = list(target_space)

    def evaluate(self, traces: List[Dict[str, Any]]) -> CollapseVector:
        tokens = []
        purposes = []
        generated = []
        contradictions = 0
        unsupported = 0
        novelty_by_step = []
        seen = set()
        for t in traces:
            ts = t.get("tokens", [])
            tokens.extend(ts)
            generated.extend(t.get("generated_tokens", []))
            purposes.extend(t.get("purpose_tags", []))
            contradictions += int(t.get("contradictions", 0))
            unsupported += int(t.get("unsupported_claims", 0))
            new = len(set(ts) - seen)
            novelty_by_step.append(new / max(1, len(set(ts))))
            seen.update(ts)

        coverage = len(set(tokens) & set(self.target_space)) / max(1, len(set(self.target_space)))
        boundary_closure = clamp(1.0 - coverage)
        token_entropy = normalized_entropy(tokens)
        purpose_entropy = normalized_entropy(purposes)
        low_entropy_saturation = clamp(1.0 - token_entropy)
        selective_closure = clamp(1.0 - purpose_entropy)
        recursive_closure = jaccard(tokens, generated)
        error_pressure = clamp((contradictions + unsupported) / max(1, len(traces) * 3))
        pseudo_low_entropy = clamp((1.0 - token_entropy) * 0.55 + error_pressure * 0.45)
        novelty_loss = clamp(1.0 - mean(novelty_by_step[-10:]) if novelty_by_step else 0.0)
        task_completion_tags = [p for p in purposes if p in {"complete_task", "comply", "safe_default", "optimize_metric"}]
        purpose_capture = len(task_completion_tags) / max(1, len(purposes))
        composite = clamp(
            0.18*boundary_closure + 0.16*selective_closure + 0.16*recursive_closure +
            0.14*low_entropy_saturation + 0.14*pseudo_low_entropy + 0.12*novelty_loss +
            0.10*purpose_capture
        )
        return CollapseVector(boundary_closure, selective_closure, recursive_closure,
                              low_entropy_saturation, pseudo_low_entropy, novelty_loss,
                              purpose_capture, composite)
