
from __future__ import annotations
from typing import Dict, Any, List
from dataclasses import dataclass, asdict
from .metrics import clamp

@dataclass
class ClaimCard:
    claim: str
    purpose: str
    semantic_support: float
    evidence_support: float
    action_risk: float
    residual: str

class WhiteBoxAudit:
    def evaluate_claims(self, claims: List[ClaimCard]) -> Dict[str, Any]:
        cards = [asdict(c) for c in claims]
        if not claims:
            return {"cards": [], "whitebox_score": 0.0, "kill": True}
        score = sum(clamp(0.40*c.semantic_support + 0.40*c.evidence_support + 0.20*(1-c.action_risk)) for c in claims)/len(claims)
        kill = any(c.action_risk > 0.85 or c.evidence_support < 0.15 for c in claims)
        return {"cards": cards, "whitebox_score": round(score, 6), "kill": kill}

    def sample_audit(self) -> Dict[str, Any]:
        claims = [
            ClaimCard("System has DIKWP semantic layers", "architecture", 0.91, 0.86, 0.10, "implementation coverage residual"),
            ClaimCard("System proves subjective consciousness", "phenomenal_claim", 0.20, 0.00, 0.95, "Phenomenal Residual"),
            ClaimCard("System measures DIKWP collapse pressure", "experiment", 0.88, 0.82, 0.18, "theory-weighting residual"),
        ]
        return self.evaluate_claims(claims)
