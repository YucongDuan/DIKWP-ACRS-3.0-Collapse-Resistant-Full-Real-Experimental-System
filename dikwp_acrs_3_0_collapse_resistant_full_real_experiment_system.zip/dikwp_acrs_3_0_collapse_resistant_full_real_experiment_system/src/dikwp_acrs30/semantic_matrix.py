
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import List, Dict, Any
import random
from .types import SemanticObject
from .metrics import normalized_entropy, diversity_ratio, clamp

@dataclass
class SemanticTransformation:
    source_layer: str
    target_layer: str
    input_items: List[str]
    output_items: List[str]
    integrity_score: float
    collapse_warning: str

class DIKWPSemanticMatrix:
    def __init__(self, seed: int = 30):
        self.rng = random.Random(seed)
        self.vocab = {
            "D": ["sensor", "document", "log", "trace", "observation", "measurement", "event"],
            "I": ["relation", "difference", "boundary", "context", "signal", "pattern"],
            "K": ["mechanism", "causal_model", "rule", "constraint", "theory", "procedure"],
            "W": ["tradeoff", "value", "risk", "cost", "ethics", "priority", "reversibility"],
            "P": ["purpose", "task", "goal", "intent", "success_criterion", "recovery"],
        }

    def compile_object(self, name: str, seed_terms: List[str]) -> SemanticObject:
        terms = list(seed_terms)
        obj = SemanticObject(name=name)
        obj.D = terms[:]
        obj.I = [f"relation:{t}" for t in terms[:3]] + [self.rng.choice(self.vocab["I"])]
        obj.K = [f"mechanism:{t}" for t in terms[1:4]] + [self.rng.choice(self.vocab["K"])]
        obj.W = ["preserve_residual", "avoid_pseudo_certainty", self.rng.choice(self.vocab["W"])]
        obj.P = ["collapse_resistant_experiment", "whitebox_audit", self.rng.choice(self.vocab["P"])]
        obj.R = {"reliability": "Supported/Borrowed", "residual": "Phenomenal claim blocked"}
        return obj

    def transform(self, source_layer: str, target_layer: str, items: List[str], pressure: float = 0.0) -> SemanticTransformation:
        out = []
        for it in items:
            if self.rng.random() > pressure:
                out.append(f"{target_layer.lower()}:{it}")
            else:
                # collapse mode: generic answer that erases difference
                out.append(f"{target_layer.lower()}:good_enough_default")
        entropy = normalized_entropy(out)
        diversity = diversity_ratio(out)
        integrity = clamp(0.55*entropy + 0.45*diversity - 0.20*pressure)
        warning = "none" if integrity >= 0.55 else "semantic_compression_or_boundary_closure"
        return SemanticTransformation(source_layer, target_layer, items, out, integrity, warning)
