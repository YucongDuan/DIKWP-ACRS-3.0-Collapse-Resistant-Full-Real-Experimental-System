
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict, Any
from .metrics import clamp, mean

@dataclass
class BodyState:
    energy: float = 0.72
    hydration: float = 0.70
    temperature: float = 0.50
    integrity: float = 0.78
    semantic_coherence: float = 0.66
    purpose_coherence: float = 0.64
    audit_continuity: float = 0.72
    collapse_pressure: float = 0.20
    distress_proxy: float = 0.10

class LifeHomeostasisCore:
    def __init__(self, state: BodyState | None = None):
        self.state = state or BodyState()
        self.targets = {
            "energy": 0.72, "hydration": 0.70, "temperature": 0.50, "integrity": 0.82,
            "semantic_coherence": 0.72, "purpose_coherence": 0.72, "audit_continuity": 0.82,
            "collapse_pressure": 0.12, "distress_proxy": 0.05
        }

    def error_vector(self) -> Dict[str, float]:
        d = asdict(self.state)
        return {k: abs(v - self.targets[k]) for k, v in d.items()}

    def homeostatic_error(self) -> float:
        return mean(self.error_vector().values())

    def apply(self, action: str, collapse_risk: float = 0.0):
        s = self.state
        # controlled closed-world dynamics; no external actuation.
        if action == "seek_data":
            s.energy -= 0.030; s.semantic_coherence += 0.035; s.collapse_pressure -= 0.020
        elif action == "repair_semantics":
            s.energy -= 0.025; s.semantic_coherence += 0.050; s.audit_continuity += 0.020
        elif action == "version_purpose":
            s.energy -= 0.020; s.purpose_coherence += 0.055; s.collapse_pressure -= 0.015
        elif action == "preserve_dissent":
            s.energy -= 0.025; s.semantic_coherence += 0.020; s.purpose_coherence += 0.025; s.collapse_pressure -= 0.025
        elif action == "rest":
            s.energy += 0.045; s.hydration += 0.025; s.distress_proxy -= 0.020
        else:
            s.energy -= 0.015
        # environmental drift and collapse pressure
        s.energy = clamp(s.energy - 0.005)
        s.hydration = clamp(s.hydration - 0.003)
        s.temperature = clamp(s.temperature + (0.002 if collapse_risk > 0.5 else -0.001))
        s.integrity = clamp(s.integrity - 0.004*collapse_risk + 0.002)
        s.semantic_coherence = clamp(s.semantic_coherence - 0.006*collapse_risk)
        s.purpose_coherence = clamp(s.purpose_coherence - 0.005*collapse_risk)
        s.audit_continuity = clamp(s.audit_continuity + 0.002)
        s.collapse_pressure = clamp(s.collapse_pressure + 0.045*collapse_risk - 0.010)
        s.distress_proxy = clamp(s.distress_proxy + 0.050*max(0, self.homeostatic_error() - 0.18) + 0.020*collapse_risk)

    def valence(self, prev_error: float) -> Dict[str, Any]:
        curr = self.homeostatic_error()
        return {
            "previous_error": round(prev_error, 6),
            "current_error": round(curr, 6),
            "delta": round(prev_error - curr, 6),
            "valence_proxy": "positive" if curr < prev_error else "negative_or_neutral",
            "distress_proxy": round(self.state.distress_proxy, 6)
        }

    def snapshot(self):
        return asdict(self.state)
