
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import List, Dict, Any
import random
from .metrics import clamp

@dataclass
class AntiCollapsePolicy:
    preserve_heterogeneous_models: bool = True
    preserve_real_world_data_loop: bool = True
    preserve_dissent_models: bool = True
    version_w_p_layers: bool = True
    avoid_single_unified_answer: bool = True
    external_residual_ratio: float = 0.22
    dissent_ratio: float = 0.16

@dataclass
class InterventionReport:
    policy: Dict[str, Any]
    injected_residuals: int
    dissent_events: int
    wp_version_events: int
    anti_collapse_score: float

class AntiCollapseController:
    def __init__(self, policy: AntiCollapsePolicy | None = None, seed: int = 30):
        self.policy = policy or AntiCollapsePolicy()
        self.rng = random.Random(seed)

    def intervene(self, traces: List[Dict[str, Any]], external_pool: List[str]) -> tuple[List[Dict[str, Any]], InterventionReport]:
        new_traces = []
        residuals = 0
        dissents = 0
        wp_versions = 0
        for idx, t in enumerate(traces):
            t = dict(t)
            toks = list(t.get("tokens", []))
            if self.policy.preserve_real_world_data_loop and self.rng.random() < self.policy.external_residual_ratio and external_pool:
                toks.append(self.rng.choice(external_pool))
                t["residual_tags"] = list(t.get("residual_tags", [])) + ["external_residual"]
                residuals += 1
            if self.policy.preserve_dissent_models and self.rng.random() < self.policy.dissent_ratio:
                toks.append("dissent_model_objection")
                t["purpose_tags"] = list(t.get("purpose_tags", [])) + ["preserve_dissent"]
                dissents += 1
            if self.policy.version_w_p_layers:
                t["wp_version"] = f"WP-v{idx//10 + 1}"
                wp_versions += 1
            t["tokens"] = toks
            new_traces.append(t)
        score = clamp(0.25*(residuals/max(1,len(traces))) + 0.25*(dissents/max(1,len(traces))) +
                      0.20*(wp_versions/max(1,len(traces))) +
                      0.15*float(self.policy.avoid_single_unified_answer) +
                      0.15*float(self.policy.preserve_heterogeneous_models))
        report = InterventionReport(asdict(self.policy), residuals, dissents, wp_versions, score)
        return new_traces, report
