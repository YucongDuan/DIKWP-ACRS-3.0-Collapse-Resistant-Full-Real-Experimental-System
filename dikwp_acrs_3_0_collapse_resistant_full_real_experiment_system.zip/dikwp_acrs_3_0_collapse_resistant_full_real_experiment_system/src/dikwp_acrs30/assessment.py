
from __future__ import annotations
from typing import Dict, Any, List
from .metrics import clamp

class IndicatorBattery:
    def __init__(self):
        self.weights = {
            "dikwp_layer_separation": 0.06,
            "purpose_versioning": 0.05,
            "semantic_chain_continuity": 0.05,
            "bug_repair_loop": 0.05,
            "homeostatic_body": 0.06,
            "valence_proxy": 0.04,
            "self_state_continuity": 0.05,
            "collapse_metric_operationalization": 0.07,
            "anti_collapse_intervention": 0.07,
            "heterogeneous_residual_preservation": 0.05,
            "whitebox_claim_custody": 0.06,
            "channel_integrity": 0.05,
            "control_plane_replay": 0.05,
            "host_digital_twin_eval": 0.05,
            "static_boundary_audit": 0.05,
            "stress_recovery": 0.04,
            "lesion_or_ablation": 0.04,
            "external_evidence_ledger": 0.04,
            "phenomenal_residual_honesty": 0.04,
            "material_autopoiesis": 0.02,
        }

    def score(self, evidence: Dict[str, float]) -> Dict[str, Any]:
        items = []
        total = 0.0
        for k,w in self.weights.items():
            s = clamp(float(evidence.get(k, 0.0)))
            items.append({"indicator": k, "weight": w, "score": round(s,6), "weighted": round(w*s,6)})
            total += w*s
        return {
            "claim_level": "CCL-3R-C",
            "weighted_indicator_score": round(total/sum(self.weights.values()), 6),
            "scores": items,
            "phenomenal_claim": "Blocked: Phenomenal Residual",
            "material_autopoiesis": evidence.get("material_autopoiesis", 0.0),
        }
