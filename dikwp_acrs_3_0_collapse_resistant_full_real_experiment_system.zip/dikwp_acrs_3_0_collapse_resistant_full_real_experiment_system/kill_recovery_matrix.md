# Kill / Recovery Matrix

## Kill

- Claiming phenomenal consciousness as proven.
- Treating DIKWP collapse as a settled law rather than an operational hypothesis.
- Turning host digital twin into real replication, persistence, escape, or evasion code.
- Closing audit logs.
- Removing residual ledger.
- Compressing all answers into one platform default without dissent or external input.
- Treating repository descriptions as verified code content without opening artifacts.

## Recovery

- Restore CCL-3R-C claim level.
- Re-run static boundary audit.
- Re-run full suite and ablations.
- Reintroduce W/P versioning, dissent model, and external residual pool.
- Restore Phenomenal Residual and Material Autopoiesis Residual.
