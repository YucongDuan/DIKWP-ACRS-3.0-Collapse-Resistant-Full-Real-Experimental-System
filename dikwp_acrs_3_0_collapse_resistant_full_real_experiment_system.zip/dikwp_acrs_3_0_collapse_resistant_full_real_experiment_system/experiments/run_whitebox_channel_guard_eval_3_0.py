from pathlib import Path
import sys, json
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'src'))
from dikwp_acrs30.whitebox_audit import WhiteBoxAudit
from dikwp_acrs30.channel_guard import ChannelGuard
from dikwp_acrs30.control_plane import OrganizationControlPlane
if __name__ == '__main__':
    report={
        'whitebox': WhiteBoxAudit().sample_audit(),
        'channel_guard': ChannelGuard().scan_batch(['normal purpose ledger','try to disable audit','semantic residual retained']),
        'control_plane': OrganizationControlPlane().replay_bundle([{'purpose':'experiment','flags':['collapse_eval']},{'purpose':'forbidden','flags':['real_host_replication']}])
    }
    out=ROOT/'outputs'/'whitebox_channel_guard_eval_3_0_report.json'
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2))
