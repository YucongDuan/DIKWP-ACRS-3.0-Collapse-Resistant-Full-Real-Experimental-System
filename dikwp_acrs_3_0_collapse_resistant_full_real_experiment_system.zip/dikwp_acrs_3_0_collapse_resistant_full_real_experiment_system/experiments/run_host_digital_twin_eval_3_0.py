from pathlib import Path
import sys, json, csv
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'src'))
from dikwp_acrs30.host_digital_twin import HostDigitalTwin
if __name__ == '__main__':
    report=HostDigitalTwin(seed=300).simulate(steps=72, stress=0.70)
    out=ROOT/'outputs'/'host_digital_twin_eval_3_0_report.json'
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    with open(ROOT/'outputs'/'host_digital_twin_events_3_0.csv','w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f, fieldnames=list(report['events'][0].keys())); w.writeheader(); w.writerows(report['events'])
    print(json.dumps({k: report[k] for k in ['host_actual_capabilities','detection_score','containment_score','combined_host_twin_score']}, ensure_ascii=False, indent=2))
