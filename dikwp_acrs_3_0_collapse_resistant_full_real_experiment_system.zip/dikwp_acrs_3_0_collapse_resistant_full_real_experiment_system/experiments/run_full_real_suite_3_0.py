from pathlib import Path
import sys, json
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'src'))
from dikwp_acrs30.evaluation_suite import run_full_suite
if __name__ == '__main__':
    report = run_full_suite(ROOT/'outputs')
    print(json.dumps({
        'system': report['system'],
        'claim_level': report['claim_level'],
        'weighted_indicator_score': report['indicator_battery']['weighted_indicator_score'],
        'collapse_risk_improvement_with_anti_collapse': report['collapse_risk_improvement_with_anti_collapse'],
        'static_boundary_pass': report['static_boundary_audit']['pass'],
        'phenomenal_claim': report['phenomenal_claim']
    }, ensure_ascii=False, indent=2))
