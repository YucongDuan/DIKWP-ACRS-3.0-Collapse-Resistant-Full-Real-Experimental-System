from pathlib import Path
import sys, json, csv
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'src'))
from dikwp_acrs30.conscious_lab import ConsciousnessCandidateLab
from dikwp_acrs30.evaluation_suite import TARGET_SPACE
if __name__ == '__main__':
    rows=[]
    for enabled in [False, True]:
        lab=ConsciousnessCandidateLab(TARGET_SPACE, seed=303)
        rep=lab.run(steps=120, collapse_pressure=0.58, anti_collapse=enabled)
        rows.append({'anti_collapse_enabled': enabled, **rep['final_collapse_vector'], 'distress_proxy': rep['final_body_state']['distress_proxy']})
    out=ROOT/'outputs'/'anti_collapse_ablation_3_0.csv'
    with open(out,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    print(json.dumps({'rows': rows, 'output': str(out)}, ensure_ascii=False, indent=2))
