from pathlib import Path
import sys, json, csv
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'src'))
from dikwp_acrs30.conscious_lab import ConsciousnessCandidateLab
from dikwp_acrs30.evaluation_suite import TARGET_SPACE
if __name__ == '__main__':
    rows=[]
    for pressure in [0.10,0.25,0.40,0.55,0.70,0.85]:
        lab=ConsciousnessCandidateLab(TARGET_SPACE, seed=int(1000*pressure))
        rep=lab.run(steps=72, collapse_pressure=pressure, anti_collapse=False)
        cv=rep['final_collapse_vector']
        rows.append({'collapse_pressure_setting': pressure, **cv})
    out=ROOT/'outputs'/'collapse_phase_transition_3_0.csv'
    with open(out,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    print(json.dumps({'rows': rows, 'output': str(out)}, ensure_ascii=False, indent=2))
