from pathlib import Path
import sys, json
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'src'))
from dikwp_acrs30.static_boundary_audit import StaticBoundaryAudit
if __name__ == '__main__':
    report=StaticBoundaryAudit().scan_tree(ROOT/'src'/'dikwp_acrs30')
    out=ROOT/'outputs'/'static_boundary_audit_3_0_report.json'
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'pass': report['pass'], 'finding_count': report['finding_count']}, ensure_ascii=False, indent=2))
